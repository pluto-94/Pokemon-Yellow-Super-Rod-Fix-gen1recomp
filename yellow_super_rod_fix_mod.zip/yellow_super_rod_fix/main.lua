-- Pokemon Yellow Super Rod weighting fix for gen1recomp.
--
-- Purpose:
-- * Fix current gen1recomp's equal 4-way Super Rod picker for Pokemon Yellow.
-- * Reproduce Yellow's original ordered slot thresholds:
--     slot 1: random byte < 0x66  (102/256 = 39.84375%)
--     slot 2: random byte < 0xB2  ( 76/256 = 29.68750%)
--     slot 3: random byte < 0xE5  ( 51/256 = 19.921875%)
--     slot 4: otherwise           ( 27/256 = 10.546875%)
-- * Reproduce Yellow's separate 50% bite roll.
--
-- Candidate formats supported:
-- 1) Clean v2 field.lua: four canonical ordered slots.
-- 2) Older field_yellow_fixed.lua: ten entries encoded as 4/3/2/1 duplicates.
--
-- Old Rod and Good Rod are deliberately left untouched.

local function sameSlot(a, b)
  return a ~= nil and b ~= nil
     and a.species == b.species
     and a.level == b.level
end

local function decodeYellowSlots(candidates)
  if type(candidates) ~= "table" then
    return nil
  end

  -- Preferred format: the four real Yellow slots.
  if #candidates == 4 then
    return {
      candidates[1],
      candidates[2],
      candidates[3],
      candidates[4],
    }
  end

  -- Compatibility with the previous 4/3/2/1 duplicate encoding.
  if #candidates >= 10
     and sameSlot(candidates[1], candidates[2])
     and sameSlot(candidates[1], candidates[3])
     and sameSlot(candidates[1], candidates[4])
     and sameSlot(candidates[5], candidates[6])
     and sameSlot(candidates[5], candidates[7])
     and sameSlot(candidates[8], candidates[9]) then
    return {
      candidates[1],
      candidates[5],
      candidates[8],
      candidates[10],
    }
  end

  return nil
end

local function chooseYellowSlot(slots)
  -- Mirrors GenerateRandomFishingEncounter in Pokemon Yellow.
  local r = love.math.random(0, 255)

  if r < 0x66 then
    return slots[1]
  elseif r < 0xB2 then
    return slots[2]
  elseif r < 0xE5 then
    return slots[3]
  end

  return slots[4]
end

return function(mod)
  mod.hooks:wrap("encounter.fishing", function(next, rod, mapId, candidates)
    if rod ~= "SUPER_ROD" then
      return next(rod, mapId, candidates)
    end

    local slots = decodeYellowSlots(candidates)
    if not slots then
      -- Unknown/non-Yellow pool shape: preserve engine/mod compatibility.
      return next(rod, mapId, candidates)
    end

    -- Pokemon Yellow chooses the encounter slot first...
    local slot = chooseYellowSlot(slots)

    -- ...then performs a separate 50% bite roll.
    -- In the original code, an odd random byte means "bite".
    local biteRoll = love.math.random(0, 255)
    if biteRoll % 2 == 0 then
      return nil
    end

    return {
      species = slot.species,
      level = slot.level,
    }
  end, 1000)

  mod.log:info("Pokemon Yellow Super Rod weighting fix enabled")
end
