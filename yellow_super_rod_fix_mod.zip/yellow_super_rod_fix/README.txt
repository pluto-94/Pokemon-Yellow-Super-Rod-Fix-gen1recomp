Pokemon Yellow Super Rod Fix
============================

Empfohlene Installation (Windows)
---------------------------------
1. Entpacke den Ordner "yellow_super_rod_fix" nach:
   %APPDATA%\pokemon-love2d\mods\
   bzw. in den mods-Ordner deiner gen1recomp-Installation.

2. Optional, aber empfohlen:
   Ersetze deine bisherige generierte field.lua durch
   field_yellow_fixed_v2.lua (lokal wieder in field.lua umbenennen).

3. Starte gen1recomp neu und aktiviere "Pokemon Yellow Super Rod Fix"
   im Mod-Manager.

4. Der Mod verändert NUR die SUPER_ROD-Auswahl.
   OLD_ROD und GOOD_ROD bleiben vollständig bei der Engine.

Kompatibilität
--------------
Der Mod versteht beide Datenformate:
- v2: vier echte Yellow-Slots pro Karte
- alte Korrektur: 10 Einträge als 4/3/2/1-Duplikate

Dadurch kannst du zuerst nur den Mod testen, ohne sofort field.lua zu tauschen.

Technik
-------
Pokemon Yellow verwendet für die vier Superangel-Slots einen 8-Bit-Zufallswert:
- Slot 1: 102/256 = 39.84375 %
- Slot 2:  76/256 = 29.68750 %
- Slot 3:  51/256 = 19.921875 %
- Slot 4:  27/256 = 10.546875 %

Danach folgt ein separater 50-%-Bisswurf.

Die bisherige 10er-Duplikatdatei allein funktioniert in der aktuellen
gen1recomp-Engine nicht korrekt, weil deren Standardauswahl nur vier
Kandidaten adressiert.
